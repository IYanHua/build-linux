#ifndef __WCN_OP_H__
#define __WCN_OP_H__

int wcn_op_init(void);
void wcn_op_exit(void);

#endif
