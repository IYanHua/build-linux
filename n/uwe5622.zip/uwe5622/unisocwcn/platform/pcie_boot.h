#include <marlin_platform.h>

int pcie_boot(enum marlin_sub_sys subsys);

